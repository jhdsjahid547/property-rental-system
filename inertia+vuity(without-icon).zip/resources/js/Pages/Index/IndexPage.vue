<template>
    <h2 class="bg-red">Hello</h2>
</template>